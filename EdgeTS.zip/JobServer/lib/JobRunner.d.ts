export declare class JobRunner {
    static index(): Promise<boolean>;
}
export default JobRunner;
