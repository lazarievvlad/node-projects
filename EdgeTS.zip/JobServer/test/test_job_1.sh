#!/bin/sh

echo "Job 1 is running, args:", $*