
import * as EdgeApiServer from './src/EdgeApiServer';

// Brian:  This should not be needed.   EdgeApi reads REDIS_HOST for TEST mode.

const server = EdgeApiServer.startServer();