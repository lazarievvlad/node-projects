export interface IPriorityType {
    priority: number;
}
