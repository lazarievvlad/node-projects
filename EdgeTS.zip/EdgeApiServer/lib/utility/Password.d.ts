export declare function generatePasswordHash(password: string): string;
