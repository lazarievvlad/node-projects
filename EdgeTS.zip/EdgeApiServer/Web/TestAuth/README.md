# EdgeApiServer /TestAuth

Simple test pages and auth script.
