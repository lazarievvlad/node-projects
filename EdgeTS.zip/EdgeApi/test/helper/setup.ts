// Do setup for testing.

// Start server for testing
import './server';